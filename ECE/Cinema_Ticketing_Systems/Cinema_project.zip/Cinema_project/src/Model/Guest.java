/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author dckt2
 */
public class Guest extends Customer{
    
    public Guest(){
        this.setId(0); //default value for a non-member customer
    }
    
}
